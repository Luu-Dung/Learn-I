#define UTS_RELEASE "3.18.0-10-generic"
#define UTS_UBUNTU_RELEASE_ABI 10
